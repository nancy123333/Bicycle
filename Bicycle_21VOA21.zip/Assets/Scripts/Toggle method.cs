using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Togglemethod : MonoBehaviour
{
    public GameObject cycleComponenet;
    private bool isVisible = true;

    public void Toggle()
    {
     if(isVisible)
     {
        cycleComponenet.SetActive(false);
        isVisible = false;
     } 
     else
     {
        cycleComponenet.SetActive(true);
        isVisible = true; 
     }  
    }
}
